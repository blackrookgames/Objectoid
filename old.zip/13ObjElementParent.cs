﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Objectoid.Abstract;

namespace Objectoid
{
    /// <summary>Represents a parent element</summary>
    public abstract class ObjElementParent : ObjElement
    {
        /// <summary>Constructor for <see cref="ObjElementParent"/></summary>
        /// <param name="canHaveParent">Whether or not the element can have a parent</param>
        /// <param name="type">Value type</param>
        private protected ObjElementParent(bool canHaveParent, ValueType type) : 
            base(canHaveParent, type) 
        { }

        private HashSet<ObjElement> _Children;

        /// <summary>Child elements</summary>
        public IEnumerable<ObjElement> Children => _Children;

        /// <summary>Number of child elements</summary>
        public int ChildCount => _Children.Count;

        /// <summary>Adds the specified element as a child</summary>
        /// <param name="element">Element to add</param>
        /// <exception cref="ArgumentNullException"><paramref name="element"/> is null</exception>
        /// <exception cref="ArgumentException"><paramref name="element"/> cannot have a parent
        /// <br/>or
        /// <br/><paramref name="element"/> is already the child of a parent</exception>
        private protected void AddChild_m(ObjElement element)
        {
            try
            {
                if (!element.CanHaveParent)
                    throw new ArgumentException("Element cannot have a parent.");
                if (element.Parent != null)
                    throw new ArgumentException("Element is already the child of a parent.");
                element.SetParent_m(this);
                _Children.Add(element);
            }
            catch when (element == null)
            {
                throw new ArgumentNullException(nameof(element));
            }
        }

        /// <summary>Removes the specified child element
        /// <br/>NOTE: It is assumed <paramref name="element"/> is a child of this</summary>
        /// <param name="element">Element to remove</param>
        private protected void RemoveChild_m(ObjElement element)
        {
            _Children.Remove(element);
            element.SetParent_m(null);
        }

        /// <summary>Clears all children</summary>
        private protected void ClearChildren_m()
        {
            foreach (var child in _Children)
                child.SetParent_m(null);
            _Children.Clear();
        }
    }
}
