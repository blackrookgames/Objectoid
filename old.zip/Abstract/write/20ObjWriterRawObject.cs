﻿using System;
using System.IO;

namespace Objectoid.Abstract
{
    /// <summary>Represents a raw object to be written to a stream</summary>
    public partial class ObjWriterRawObject
    {
        /// <summary>Constructor for <see cref="ObjWriterRawObject"/>
        /// <br/>NOTE: It is assumed <paramref name="writer"/> is not null</summary>
        /// <param name="writer">Writer associated with the raw object</param>
        internal ObjWriterRawObject(ObjWriter writer)
        {
            _Writer = writer;
        }

        #region Writer

        private readonly ObjWriter _Writer;

        /// <summary>Writer associated with the raw object</summary>
        public ObjWriter Writer => _Writer;

        #endregion

        #region IsWritten

        private bool _IsWritten;

        /// <summary>Whether or not the raw object has been written to the stream</summary>
        public bool IsWritten => _IsWritten;

        /// <summary>Marks the raw object as written</summary>
        internal void MarkAsWritten_m() => _IsWritten = true;

        #endregion

        #region PropertyCount

        private int __PropertyCount;

        /// <summary>Number of properties</summary>
        public int PropertyCount => __PropertyCount;

        #endregion

    }
}
