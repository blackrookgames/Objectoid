﻿using System;
using System.IO;
using Objectoid.Abstract;

namespace Objectoid
{
    /// <summary>Represents an element inside an Objectoid document</summary>
    public abstract class ObjElement
    {
        /// <summary>Constructor for <see cref="ObjElement"/></summary>
        /// <param name="canHaveParent">Whether or not the element can have a parent</param>
        /// <param name="type">Value type</param>
        private protected ObjElement(bool canHaveParent, ValueType type)
        {
            _CanHaveParent = canHaveParent;
            _Type = type;
        }

        #region CanHaveParent

        private readonly bool _CanHaveParent;

        /// <summary>Whether or not the element can have a parent</summary>
        public bool CanHaveParent => _CanHaveParent;

        #endregion

        #region Parent

        private ObjElementParent fParent;

        /// <summary>Parent element</summary>
        public ObjElementParent Parent => fParent;

        /// <summary>Sets the parent of the element
        /// <br/>CALLED BY: <see cref="ObjElementParent"/></summary>
        /// <param name="parent">Parent</param>
        internal void SetParent_m(ObjElementParent parent)
        {
            fParent = parent;
        }

        #endregion

        #region Type

        private readonly ValueType _Type;

        /// <summary>Value type</summary>
        public ValueType Type => _Type;

        #endregion

        /// <summary>Loads data using the specified reader property
        /// <br/>NOTE: It is assumed <paramref name="property"/> is not null</summary>
        /// <param name="property">Reader object</param>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">The stream associated with the property has already been disposed</exception>
        /// <exception cref="EndOfStreamException">Reached the end of the stream associated with the property</exception>
        /// <exception cref="InvalidDataException">The stream associated with the property has invalid data</exception>
        private protected abstract void Load_m(ObjReaderProperty property);
    }
}
