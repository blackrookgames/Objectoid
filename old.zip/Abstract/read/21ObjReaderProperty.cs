﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Objectoid.Abstract
{
    /// <summary>Represents a property of a raw object</summary>
    public class ObjReaderProperty
    {
        /// <summary>Constructor for <see cref="ObjReaderProperty"/>
        /// <br/>NOTE: It is assumed none of the arguments are null
        /// <br/>NOTE: It is assumed <paramref name="address"/> is valid</summary>
        /// <param name="rawObject">Raw object associated with the property</param>
        /// <param name="address">Stream position where the property is defined</param>
        /// <param name="name">Name of the property</param>
        /// <param name="value">Value of the property</param>
        internal ObjReaderProperty(ObjReaderRawObject rawObject, long address, PropertyName name, ObjReaderValue value)
        {
            _RawObject = rawObject;
            _Address = address;
            _Name = name;
            _Value = value;
        }

        #region RawObject

        private readonly ObjReaderRawObject _RawObject;

        /// <summary>Raw object associated with the property</summary>
        public ObjReaderRawObject RawObject => _RawObject;

        #endregion

        #region Address

        private readonly long _Address;

        /// <summary>Stream position where the property is defined</summary>
        public long Address => _Address;

        #endregion

        #region Name

        private readonly PropertyName _Name;

        /// <summary>Name of the property</summary>
        public PropertyName Name => _Name;

        #endregion

        #region Value

        private readonly ObjReaderValue _Value;

        /// <summary>Value of the property</summary>
        public ObjReaderValue Value => _Value;

        #endregion
    }
}
