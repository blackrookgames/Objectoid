﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Objectoid.Abstract
{
    /// <summary>Represents a value inside a raw object</summary>
    public partial class ObjReaderValue
    {
        /// <summary>Constructor for <see cref="ObjReaderValue"/>
        /// <br/>NOTE: It is assumed <paramref name="rawObject"/> is not null
        /// <br/>NOTE: It is assumed <paramref name="address"/> is valid
        /// <br/>NOTE: It is assumed <paramref name="type"/> is valid</summary>
        /// <param name="rawObject">Raw object associated with the value</param>
        /// <param name="address">Stream position where the value is defined</param>
        /// <param name="type">Value type</param>
        /// <param name="value">Actual value (for references this is the stream position where the instance is defined)</param>
        internal ObjReaderValue(ObjReaderRawObject rawObject, long address, ValueType type, object value)
        {
            _RawObject = rawObject;
            _Address = address;
            _Type = type;
            _Value = value;
        }

        #region RawObject

        private readonly ObjReaderRawObject _RawObject;

        /// <summary>Raw object associated with the value</summary>
        public ObjReaderRawObject RawObject => _RawObject;

        #endregion

        #region Address

        private readonly long _Address;

        /// <summary>Stream position where the value is defined</summary>
        public long Address => _Address;

        #endregion

        #region Type

        private readonly ValueType _Type;

        /// <summary>Value type</summary>
        public ValueType Type => _Type;

        #endregion

        #region Value

        private readonly object _Value;

        /// <summary>Actual value (for references this is the stream position where the instance is defined)</summary>
        public object Value => _Value;

        #endregion

        /// <summary>Reads object data to the specified object</summary>
        /// <exception cref="ArgumentNullException"><paramref name="object"/> is null</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        public void ReadObject(IObjObject @object)
        {
            if (@object == null)
                throw new ArgumentNullException(nameof(@object));
            if (_Type != ValueType.Object) throw ObjReader.InvalidData_m(_Address,
                "Value is not an object value.");
            ObjReaderRawObject rawObject = _RawObject.Reader.ReadObject_m((int)_Value);
            @object.Load(rawObject);
        }
    }
}
