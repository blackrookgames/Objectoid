﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Objectoid.Abstract
{
    /// <summary>Represents an object inside an Objectoid-structured document</summary>
    public interface IObjObject
    {
        /// <summary>Loads data using the specified raw object</summary>
        /// <param name="rawObject">Raw object</param>
        /// <exception cref="ArgumentNullException"><paramref name="rawObject"/> is null</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">The stream associated with the raw object has already been disposed</exception>
        /// <exception cref="EndOfStreamException">Reached the end of the stream associated with the raw object</exception>
        /// <exception cref="InvalidDataException">The stream associated with the raw object has invalid data</exception>
        void Load(ObjReaderRawObject rawObject);

        /// <summary>Saves data using the specified raw object</summary>
        /// <param name="rawObject">Raw object</param>
        /// <exception cref="ArgumentNullException"><paramref name="rawObject"/> is null</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">The stream associated with the raw object has already been disposed</exception>
        void Save(ObjWriterRawObject rawObject);
    }
}
