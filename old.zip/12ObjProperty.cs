﻿using System;
using Objectoid.Abstract;

namespace Objectoid
{
    /// <summary>Represents a property of an object</summary>
    public struct ObjProperty
    {
        /// <summary>Constructor for <see cref="ObjProperty"/>
        /// <br/>NOTE: It is assumed neither <paramref name="name"/> nor <paramref name="value"/> are null</summary>
        /// <param name="name">Name of the property</param>
        /// <param name="value">Value of the property</param>
        internal ObjProperty(PropertyName name, ObjElement value)
        {
            Name = name;
            Value = value;
        }

        /// <summary>Name of the property</summary>
        public PropertyName Name { get; }

        /// <summary>Value of the property</summary>
        public ObjElement Value { get; }
    }
}
