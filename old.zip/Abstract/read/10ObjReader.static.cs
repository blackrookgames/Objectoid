﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Objectoid.Abstract
{
    public partial class ObjReader
    {
        static ObjReader()
        {
            _ReadValueMethods = new Dictionary<ValueType, ReadValueMethod_>();

            _ReadValueMethods.Add(ValueType.Object, (ObjReaderRawObject rawObject) => 
            {
                long address = rawObject.Reader.Stream.Position;
                int value = rawObject.Reader.ReadAddress_m();
                return new ObjReaderValue(rawObject, address, ValueType.Object, value);
            });

            _ReadValueMethods.Add(ValueType.PropertyName, (ObjReaderRawObject rawObject) => 
            {
                long address = rawObject.Reader.Stream.Position;
                int value = rawObject.Reader.ReadAddress_m();
                return new ObjReaderValue(rawObject, address, ValueType.PropertyName, value);
            });

            _ReadValueMethods.Add(ValueType.String, (ObjReaderRawObject rawObject) => 
            {
                long address = rawObject.Reader.Stream.Position;
                int value = rawObject.Reader.ReadAddress_m();
                return new ObjReaderValue(rawObject, address, ValueType.String, value);
            });

            _ReadValueMethods.Add(ValueType.UInt8, (ObjReaderRawObject rawObject) => 
            {
                long address = rawObject.Reader.Stream.Position;
                byte value = rawObject.Reader.ReadUInt8_m();
                return new ObjReaderValue(rawObject, address, ValueType.UInt8, value);
            });

            _ReadValueMethods.Add(ValueType.Int8, (ObjReaderRawObject rawObject) => 
            {
                long address = rawObject.Reader.Stream.Position;
                sbyte value = rawObject.Reader.ReadInt8_m();
                return new ObjReaderValue(rawObject, address, ValueType.Int8, value);
            });

            _ReadValueMethods.Add(ValueType.UInt16, (ObjReaderRawObject rawObject) => 
            {
                long address = rawObject.Reader.Stream.Position;
                ushort value = rawObject.Reader.ReadUInt16_m();
                return new ObjReaderValue(rawObject, address, ValueType.UInt16, value);
            });

            _ReadValueMethods.Add(ValueType.Int16, (ObjReaderRawObject rawObject) => 
            {
                long address = rawObject.Reader.Stream.Position;
                short value = rawObject.Reader.ReadInt16_m();
                return new ObjReaderValue(rawObject, address, ValueType.Int16, value);
            });

            _ReadValueMethods.Add(ValueType.UInt32, (ObjReaderRawObject rawObject) => 
            {
                long address = rawObject.Reader.Stream.Position;
                uint value = rawObject.Reader.ReadUInt32_m();
                return new ObjReaderValue(rawObject, address, ValueType.UInt32, value);
            });

            _ReadValueMethods.Add(ValueType.Int32, (ObjReaderRawObject rawObject) => 
            {
                long address = rawObject.Reader.Stream.Position;
                int value = rawObject.Reader.ReadInt32_m();
                return new ObjReaderValue(rawObject, address, ValueType.Int32, value);
            });

            _ReadValueMethods.Add(ValueType.UInt64, (ObjReaderRawObject rawObject) => 
            {
                long address = rawObject.Reader.Stream.Position;
                ulong value = rawObject.Reader.ReadUInt64_m();
                return new ObjReaderValue(rawObject, address, ValueType.UInt64, value);
            });

            _ReadValueMethods.Add(ValueType.Int64, (ObjReaderRawObject rawObject) => 
            {
                long address = rawObject.Reader.Stream.Position;
                long value = rawObject.Reader.ReadInt64_m();
                return new ObjReaderValue(rawObject, address, ValueType.Int64, value);
            });

            _ReadValueMethods.Add(ValueType.Single, (ObjReaderRawObject rawObject) => 
            {
                long address = rawObject.Reader.Stream.Position;
                float value = rawObject.Reader.ReadSingle_m();
                return new ObjReaderValue(rawObject, address, ValueType.Single, value);
            });

            _ReadValueMethods.Add(ValueType.Double, (ObjReaderRawObject rawObject) => 
            {
                long address = rawObject.Reader.Stream.Position;
                double value = rawObject.Reader.ReadDouble_m();
                return new ObjReaderValue(rawObject, address, ValueType.Double, value);
            });

            _ReadValueMethods.Add(ValueType.Bool, (ObjReaderRawObject rawObject) => 
            {
                long address = rawObject.Reader.Stream.Position;
                bool value = rawObject.Reader.ReadBool_m();
                return new ObjReaderValue(rawObject, address, ValueType.Bool, value);
            });
        }

        /// <summary>Method for reading a value
        /// <br/>NOTE: It is assumed <paramref name="rawObject"/> is not null</summary>
        /// <param name="rawObject">RawObject</param>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        private delegate ObjReaderValue ReadValueMethod_(ObjReaderRawObject rawObject);
        
        private static readonly Dictionary<ValueType, ReadValueMethod_> _ReadValueMethods;
    }
}

