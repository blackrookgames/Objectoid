﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Objectoid.Abstract
{
    /// <summary>Represents a list entry</summary>
    internal struct ObjListEntry
    {
        internal ObjListEntry(ValueType type, object value)
        {
            Type = type;
            Value = value;
        }

        /// <summary>Value type</summary>
        public ValueType Type { get; }

        /// <summary>Value</summary>
        public object Value { get; }

        internal delegate void WriteMethod_()
    }
}
