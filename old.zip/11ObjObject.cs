﻿using System;
using System.Collections;
using System.Collections.Generic;
using Objectoid.Abstract;

namespace Objectoid
{
    /// <summary>Represents an object in an Objectoid document</summary>
    public class ObjObject : ObjElementParent, IObjObject, IEnumerable<ObjProperty>
    {
        #region ObjElement

        /// <inheritdoc/>
        private protected override void Load_m(ObjReaderProperty property)
        {
            property.Value.ReadObject(this);
        }

        #endregion

        #region IObjObject

        /// <inheritdoc/>
        void IObjObject.Load(ObjReaderRawObject rawObject)
        {
            //Remove old properties
            List<ObjProperty> oldProperties = new List<ObjProperty>(_Properties.Count);
            foreach (ObjProperty property in _Properties.Values)
            {
                oldProperties.Add(property);
                RemoveChild_m(property.Value);
            }
            _Properties.Clear();
            //Add new properties
            try
            {
                foreach (ObjReaderProperty property in rawObject)
                {
                    
                }
            }
            catch
            {
                ClearChildren_m();
                _Properties.Clear();
                //Re-add old properties
                foreach (ObjProperty property in oldProperties)
                {
                    _Properties.Add(property.Name, property);
                    AddChild_m(property.Value);
                }
                //Throw
                throw;
            }
        }

        /// <inheritdoc/>
        void IObjObject.Save(ObjWriterRawObject rawObject)
        {

        }

        #endregion

        #region IEnumerable

        IEnumerator IEnumerable.GetEnumerator() => _Properties.Values.GetEnumerator();

        /// <summary>Gets an enumerator for the object's properties</summary>
        /// <returns>An enumerator for the object's properties</returns>
        public IEnumerator<ObjProperty> GetEnumerator() => _Properties.Values.GetEnumerator();

        #endregion

        /// <summary>Constructor for <see cref="ObjObject"/></summary>
        /// <param name="canHaveParent">Whether or not the object can have a parent</param>
        internal ObjObject(bool canHaveParent) : base(canHaveParent, ValueType.Object)
        {
            _Properties = new Dictionary<PropertyName, ObjProperty>();
        }

        /// <summary>Creates an instance of <see cref="ObjObject"/></summary>
        public ObjObject() : this(true) { }

        private readonly Dictionary<PropertyName, ObjProperty> _Properties;

        /// <summary>Number of properties</summary>
        public int Count => _Properties.Count;

        /// <summary>Attempts to get the property with the specified name</summary>
        /// <param name="name">Name of the property</param>
        /// <param name="property">Found property</param>
        /// <returns>Whether or not successful</returns>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        public bool TryGetValue(PropertyName name, out ObjProperty property)
        {
            try
            {
                return _Properties.TryGetValue(name, out property);
            }
            catch when (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }
        }

        /// <summary>Adds a property to the object</summary>
        /// <param name="name">Property name</param>
        /// <param name="element">Property value</param>
        /// <exception cref="ArgumentException"><paramref name="name"/> is null
        /// <br/>or
        /// <br/><paramref name="element"/> is null</exception>
        /// <exception cref="ArgumentNullException">Object already contains a property with the same name
        /// <br/>or
        /// <br/><paramref name="element"/> already has a parent</exception>
        public void Add(PropertyName name, ObjElement element)
        {
            try
            {
                if (_Properties.ContainsKey(name)) throw new ArgumentException(
                    "The object already contains a property with the specified name.", nameof(name));
                AddChild_m(element); //Do this before adding to the dictionary
                _Properties.Add(name, new ObjProperty(name, element));
            }
            catch when (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }
        }

        /// <summary>Attempts to remove the property with the specified name</summary>
        /// <param name="name">Name of the property</param>
        /// <returns>Whether or not successful</returns>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        public bool Remove(PropertyName name)
        {
            try
            {
                if (!_Properties.TryGetValue(name, out ObjProperty property))
                    return false;
                _Properties.Remove(name);
                RemoveChild_m(property.Value);
                return true;
            }
            catch when (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }
        }

        /// <summary>Removes all properties from the object</summary>
        public void Clear()
        {
            ClearChildren_m();
            _Properties.Clear();
        }
    }
}
