﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;

namespace Objectoid.Abstract
{
    /// <summary>Represents a writer for an Objectoid document</summary>
    public class ObjWriter : ObjRW
    {
        #region helper

        /// <summary>Gets the address of the current stream position</summary>
        /// <returns>The address of the current stream position</returns>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="OverflowException">The current stream position is greater than <see cref="int.MaxValue"/></exception>
        private int GetCurrentAddress_m()
        {
            try
            {
                checked { return (int)Stream.Position; }
            }
            catch (OverflowException)
            {
                throw new OverflowException($"Cannot reference an address higher than {int.MaxValue}");
            }
        }

        #endregion

        /// <summary>Constructor for <see cref="ObjWriter"/></summary>
        /// <param name="stream">Stream</param>
        /// <param name="intIsLittleEndian">Whether or not integers are stored as little-endian</param>
        /// <param name="floatIsLittleEndian">Whether or not floats are stored as little-endian</param>
        /// <exception cref="ArgumentNullException"><paramref name="stream"/> is null</exception>
        /// <exception cref="ArgumentException"><paramref name="stream"/> does not support seeking
        /// <br/>or
        /// <br/><paramref name="stream"/> does not support writing</exception>
        private ObjWriter(Stream stream, bool intIsLittleEndian, bool floatIsLittleEndian) :
            base(stream)
        {
            if (!stream.CanWrite)
                throw new ArgumentException("The stream does not support writing.", nameof(stream));
            SetIntIsLittleEndian_m(intIsLittleEndian);
            SetFloatIsLittleEndian_m(floatIsLittleEndian);
        }

        /// <summary>Saves the specified object to the specified stream
        /// <br/>NOTE: It is assumed <paramref name="object"/> is not null</summary>
        /// <param name="stream">Stream</param>
        /// <param name="object">Object</param>
        /// <param name="intIsLittleEndian">Whether or not integers are stored as little-endian</param>
        /// <param name="floatIsLittleEndian">Whether or not floats are stored as little-endian</param>
        /// <exception cref="ArgumentNullException"><paramref name="stream"/> is null</exception>
        /// <exception cref="ArgumentException"><paramref name="stream"/> does not support seeking
        /// <br/>or
        /// <br/><paramref name="stream"/> does not support writing</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">The stream has already been disposed</exception>
        /// <exception cref="OverflowException">It was attempted to reference an address higher than <see cref="int.MaxValue"/></exception>
        internal static void Save_m(Stream stream, IObjObject @object, bool intIsLittleEndian, bool floatIsLittleEndian)
        {
            ObjWriter objWriter = new ObjWriter(stream, intIsLittleEndian, floatIsLittleEndian);

            long returnPos;

            //Write header
            byte flagByte = 0;
            if (intIsLittleEndian) flagByte |= 0b0001;
            if (floatIsLittleEndian) flagByte |= 0b0010;
            objWriter.WriteUInt8_m(flagByte);

            //Write placeholder for first address
            long firstAddressAddress = objWriter.Stream.Position;
            objWriter.WriteInt32_m(0);

            //Write object
            int firstAddress = objWriter.GetCurrentAddress_m();
            objWriter._ObjectQueue.WriteMethod(objWriter, @object);

            //Fix first address
            returnPos = objWriter.Stream.Position;
            objWriter.Stream.Position = firstAddressAddress;
            objWriter.WriteInt32_m(firstAddress);
            objWriter.Stream.Position = returnPos;

            //Write queue
            objWriter.SaveQueue_m(objWriter._ObjectQueue);
            objWriter.SaveQueue_m(objWriter._PropertyNameQueue);
            objWriter.SaveQueue_m(objWriter._StringQueue);
        }

        #region queues

        #region helper

        /// <summary>Saves the specified queue of instances
        /// <br/>NOTE: It is assumed <paramref name="queue"/> is not null</summary>
        /// <param name="queue">Queue of instances</param>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="OverflowException">It was attempted to reference a stream position greater than <see cref="int.MaxValue"/></exception>
        private void SaveQueue_m<T>(ObjWriterQueue<T> queue)
        {
            long returnPos;
            while (queue.TryGetInstance(out var queueEntry))
            {
                int address = GetCurrentAddress_m();
                //Add address to saved entries
                _SavedInstances.Add(queueEntry.Instance, address);
                //Write data
                queue.WriteMethod(this, queueEntry.Instance);
                //Fix references
                returnPos = Stream.Position;
                foreach (long reference in queueEntry.References)
                {
                    Stream.Position = reference;
                    WriteInt32_m(address);
                }
                Stream.Position = returnPos;
            }
        }

        /// <summary>Queues the specified instance
        /// <br/>NOTE: It is assumed neither <paramref name="queue"/> nor <paramref name="instance"/> are null</summary>
        /// <typeparam name="T">Instance type</typeparam>
        /// <param name="queue">Queue</param>
        /// <param name="instance">Instance</param>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        private void QueueInstance_m<T>(ObjWriterQueue<T> queue, T instance)
        {
            if (_SavedInstances.TryGetValue(instance, out int address))
            {
                WriteInt32_m(address);
            }
            else
            {
                queue.AddInstance(instance, Stream.Position);
                WriteInt32_m(0);
            }
        }

        #endregion

        #region Object

        private readonly ObjWriterQueue<IObjObject> _ObjectQueue =
            new ObjWriterQueue<IObjObject>((ObjWriter writer, IObjObject instance) =>
            {
                long returnAddress;

                //Write count placeholder
                long countAddress = writer.Stream.Position;
                writer.WriteInt32_m(0);

                //Write object data
                ObjWriterRawObject rawObject = new ObjWriterRawObject(writer);
                instance.Save(rawObject);
                rawObject.MarkAsWritten_m();

                //Fix count
                returnAddress = writer.Stream.Position;
                writer.Stream.Position = countAddress;
                writer.WriteInt32_m(rawObject.PropertyCount);
                writer.Stream.Position = returnAddress;
            });

        /// <summary>Queues an object
        /// <br/>NOTE: It is assumed <paramref name="object"/> is not null</summary>
        /// <param name="object">Object</param>
        internal void QueueObject_m(IObjObject @object) => QueueInstance_m(_ObjectQueue, @object);

        #endregion

        #region PropertyName

        private readonly ObjWriterQueue<PropertyName> _PropertyNameQueue =
            new ObjWriterQueue<PropertyName>((ObjWriter writer, PropertyName instance) =>
            {
                foreach (char c in instance)
                    writer.WriteUInt8_m((byte)c);
                writer.WriteUInt8_m(0);
            });

        /// <summary>Queues a property name
        /// <br/>NOTE: It is assumed <paramref name="propertyName"/> is not null</summary>
        /// <param name="propertyName">Property name</param>
        internal void QueuePropertyName_m(PropertyName propertyName) => QueueInstance_m(_PropertyNameQueue, propertyName);

        #endregion

        #region List

        private readonly ObjWriterQueue<ObjList> _ListQueue =
            new ObjWriterQueue<ObjList>((ObjWriter writer, ObjList instance) =>
            {
                //Count
                writer.WriteInt32_m(instance.Count);
                //Entries
                for (int i = 0; i < instance.Count; i++)
                {

                }


                foreach (char c in instance)
                    writer.WriteUInt8_m((byte)c);
                writer.WriteUInt8_m(0);
            });

        /// <summary>Queues a property name
        /// <br/>NOTE: It is assumed <paramref name="propertyName"/> is not null</summary>
        /// <param name="propertyName">Property name</param>
        internal void QueueList_m(ObjList propertyName) => QueueInstance_m(_ListQueue, propertyName);

        #endregion

        #region String

        private readonly ObjWriterQueue<string> _StringQueue =
            new ObjWriterQueue<string>((ObjWriter writer, string instance) =>
            {
                //Determine character size
                bool is8bit = true;
                foreach (char c in instance)
                {
                    if ((c & 0xFF00) == 0) continue;
                    is8bit = false;
                    break;
                }
                //Write header
                int header = instance.Length;
                if (is8bit) header |= int.MinValue;
                writer.WriteInt32_m(header);
                //Write characters
                if (is8bit)
                {
                    foreach (char c in instance)
                        writer.WriteUInt8_m((byte)c);
                }
                else
                {
                    foreach (char c in instance)
                        writer.WriteUInt16_m(c);
                }
            });

        /// <summary>Queues a string
        /// <br/>NOTE: It is assumed <paramref name="string"/> is not null</summary>
        /// <param name="string">String</param>
        internal void QueueString_m(string @string) => QueueInstance_m(_StringQueue, @string);

        #endregion

        private readonly Dictionary<object, int> _SavedInstances = new Dictionary<object, int>();

        #endregion
    }
}
