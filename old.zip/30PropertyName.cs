﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Xml.Linq;

namespace Objectoid
{
    /// <summary>Represents a property name</summary>
    public class PropertyName : IEnumerable<char>, IEquatable<PropertyName>
    {
        #region helper

        /// <summary>Checks if the current property name is equal in content to the specified other property name
        /// <br/>NOTE: It is assumed <paramref name="other"/> is not null</summary>
        /// <param name="other">Other property</param>
        /// <returns>Whether or not the current property name is equal in content to the specified other property name</returns>
        private bool Equals_m(PropertyName other)
        {
            if (other._Chars.Length != _Chars.Length) return false;
            for (int i = 0; i < _Chars.Length; i++)
            {
                if (other._Chars[i] != _Chars[i]) return false;
            }
            return true;
        }

        /// <summary>Checks if the property name is equal in content to the specified string
        /// <br/>NOTE: It is assumed <paramref name="s"/> is not null</summary>
        /// <param name="s">String</param>
        /// <returns>Whether or not the property name is equal in content to the specified string</returns>
        private bool Equals_m(string s)
        {
            if (s.Length != _Chars.Length) return false;
            for (int i = 0; i < _Chars.Length; i++)
            {
                if (s[i] != _Chars[i]) return false;
            }
            return true;
        }

        /// <summary>Checks if the two property names are equal in content</summary>
        /// <param name="a">Property name</param>
        /// <param name="b">Property name</param>
        /// <returns>Whether or not the two property names are equal in content</returns>
        private static bool Equals_m(PropertyName a, PropertyName b)
        {
            if (a is null || b is null)
                return (a is null && b is null);
            return a.Equals_m(b);
        }

        /// <summary>Checks if the property name and string are equal in content</summary>
        /// <param name="prop">Property name</param>
        /// <param name="s">String</param>
        /// <returns>Whether or not the property name and string are equal in content</returns>
        private static bool Equals_m(PropertyName prop, string s)
        {
            if (prop is null || s is null)
                return (prop is null && s is null);
            return prop.Equals_m(s);
        }

        #endregion

        #region object

        /// <summary>Returns the property name as a string</summary>
        /// <returns>The property name as a string</returns>
        public override string ToString()
        {
            char[] chars = new char[_Chars.Length];
            for (int i = 0; i < chars.Length; i++)
                chars[i] = (char)_Chars[i];
            return new string(chars);
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if (obj is PropertyName) return Equals_m((PropertyName)obj);
            if (obj is string) return Equals_m((string)obj);
            return false;
        }

        /// <inheritdoc/>
        public override int GetHashCode() => _Chars.Length;

        #endregion

        #region IEnumerable

        IEnumerator IEnumerable.GetEnumerator() => new Enumerator(this);

        /// <summary>Gets an enumerator for the property name</summary>
        /// <returns>An enumerator for the property name</returns>
        public IEnumerator<char> GetEnumerator() => new Enumerator(this);

        private class Enumerator : IEnumerator<char>
        {
            public Enumerator(PropertyName instance) =>
                _Instance = instance;

            private readonly PropertyName _Instance;

            private int __Position = -1;

            private char Current_p
            {
                get
                {
                    try { return (char)_Instance._Chars[__Position]; }
                    catch { throw new InvalidOperationException(); }
                }
            }
            char IEnumerator<char>.Current => Current_p;
            object IEnumerator.Current => Current_p;

            bool IEnumerator.MoveNext() => (++__Position) < _Instance._Chars.Length;

            void IEnumerator.Reset() => __Position = -1;

            void IDisposable.Dispose() { }
        }

        #endregion

        #region IEquatable

        /// <summary>Checks if the current property name is equal in content to the specified other property name</summary>
        /// <param name="other">Other property</param>
        /// <returns>Whether or not the current property name is equal in content to the specified other property name</returns>
        public bool Equals(PropertyName other)
        {
            if (other is null) return false;
            return Equals_m(other);
        }

        #endregion

        /// <summary>Constructor for <see cref="PropertyName"/>
        /// <br/>NOTE: It is assumed <paramref name="chars"/> is not null
        /// <br/>NOTE: It is assumed <paramref name="chars"/> does not exist outside this scope
        /// <br/>NOTE: It is assumed <paramref name="chars"/> does not contain any entries with a value of zero.</summary>
        /// <param name="chars">Characters</param>
        internal PropertyName(byte[] chars)
        {
            _Chars = chars;
        }

        /// <summary>Creates an instance of <see cref="PropertyName"/></summary>
        /// <param name="name">Name of the property</param>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        /// <exception cref="ArgumentException"><paramref name="name"/> contains one or more 16-bit characters
        /// <br/>or
        /// <br/><paramref name="name"/> contains one or more null characters</exception>
        public PropertyName(string name)
        {
            try
            {
                _Chars = new byte[name.Length];
                for (int i = 0; i < _Chars.Length; i++)
                {
                    byte c;
                    //Cast as byte
                    try { checked { c = (byte)name[i]; } }
                    catch { throw new ArgumentException("Property names cannot contain 16-bit characters.", nameof(name)); }
                    //Ensure character is not null
                    if (c == 0x00)
                        throw new ArgumentException("Property names cannot contain null characters.", nameof(name));
                    //Add
                    _Chars[i] = c;
                }
            }
            catch when (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }
        }

        private readonly byte[] _Chars;

        /// <summary>Length of the property name</summary>
        public int Length => _Chars.Length;

        /// <summary>Gets the character at the specified index</summary>
        /// <param name="index">Index of the character</param>
        /// <returns>The character at the specified index</returns>
        /// <exception cref="ArgumentOutOfRangeException"><paramref name="index"/> is out of range</exception>
        public char this[int index]
        {
            get
            {
                try
                {
                    return (char)_Chars[index];
                }
                catch when (index < 0 || index >= _Chars.Length)
                {
                    throw new ArgumentOutOfRangeException(nameof(index));
                }
            }
        }

        /// <summary>Checks if the property name is equal in content to the specified string</summary>
        /// <param name="s">String</param>
        /// <returns>Whether or not the property name is equal in content to the specified string</returns>
        public bool Equals(string s)
        {
            if (s == null) return false;
            return Equals_m(s);
        }
    }
}
