﻿using System;
using System.IO;

namespace Objectoid.Abstract
{
    public partial class ObjReaderValue
    {
        //Do NOT create a method for Object

        /// <summary>Reads a property name value</summary>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        public PropertyName ReadPropertyName()
        {
            if (_Type != ValueType.PropertyName) throw ObjReader.InvalidData_m(_Address,
                "Value is not a property name value.");
            return _RawObject.Reader.ReadPropertyName_m((int)_Value);
        }

        /// <summary>Reads a string value</summary>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        public string ReadString()
        {
            if (_Type != ValueType.String) throw ObjReader.InvalidData_m(_Address,
                "Value is not a string value.");
            return _RawObject.Reader.ReadString_m((int)_Value);
        }

        /// <summary>Reads an unsigned 8-bit integer value</summary>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        public byte ReadUInt8()
        {
            if (_Type != ValueType.UInt8) throw ObjReader.InvalidData_m(_Address,
                "Value is not an unsigned 8-bit integer value.");
            return (byte)_Value;
        }

        /// <summary>Reads a signed 8-bit integer value</summary>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        public sbyte ReadInt8()
        {
            if (_Type != ValueType.Int8) throw ObjReader.InvalidData_m(_Address,
                "Value is not a signed 8-bit integer value.");
            return (sbyte)_Value;
        }

        /// <summary>Reads an unsigned 16-bit integer value</summary>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        public ushort ReadUInt16()
        {
            if (_Type != ValueType.UInt16) throw ObjReader.InvalidData_m(_Address,
                "Value is not an unsigned 16-bit integer value.");
            return (ushort)_Value;
        }

        /// <summary>Reads a signed 16-bit integer value</summary>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        public short ReadInt16()
        {
            if (_Type != ValueType.Int16) throw ObjReader.InvalidData_m(_Address,
                "Value is not a signed 16-bit integer value.");
            return (short)_Value;
        }

        /// <summary>Reads an unsigned 32-bit integer value</summary>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        public uint ReadUInt32()
        {
            if (_Type != ValueType.UInt32) throw ObjReader.InvalidData_m(_Address,
                "Value is not an unsigned 32-bit integer value.");
            return (uint)_Value;
        }

        /// <summary>Reads a signed 32-bit integer value</summary>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        public int ReadInt32()
        {
            if (_Type != ValueType.Int32) throw ObjReader.InvalidData_m(_Address,
                "Value is not a signed 32-bit integer value.");
            return (int)_Value;
        }

        /// <summary>Reads an unsigned 64-bit integer value</summary>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        public ulong ReadUInt64()
        {
            if (_Type != ValueType.UInt64) throw ObjReader.InvalidData_m(_Address,
                "Value is not an unsigned 64-bit integer value.");
            return (ulong)_Value;
        }

        /// <summary>Reads a signed 64-bit integer value</summary>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        public long ReadInt64()
        {
            if (_Type != ValueType.Int64) throw ObjReader.InvalidData_m(_Address,
                "Value is not a signed 64-bit integer value.");
            return (long)_Value;
        }

        /// <summary>Reads a single-precision floating-point value</summary>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        public float ReadSingle()
        {
            if (_Type != ValueType.Single) throw ObjReader.InvalidData_m(_Address,
                "Value is not a single-precision floating-point value.");
            return (float)_Value;
        }

        /// <summary>Reads a double-precision floating-point value</summary>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        public double ReadDouble()
        {
            if (_Type != ValueType.Double) throw ObjReader.InvalidData_m(_Address,
                "Value is not a double-precision floating-point value.");
            return (double)_Value;
        }

        /// <summary>Reads a boolean value</summary>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        public bool ReadBool()
        {
            if (_Type != ValueType.Bool) throw ObjReader.InvalidData_m(_Address,
                "Value is not a boolean value.");
            return (bool)_Value;
        }
    }
}

