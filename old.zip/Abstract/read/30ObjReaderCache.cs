﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Objectoid.Abstract
{
    /// <summary>Represents a cache of loaded referenced instances</summary>
    /// <typeparam name="T">Instance type</typeparam>
    internal class ObjReaderCache<T>
    {
        /// <summary>Reads an instance from the stream
        /// <br/>NOTE: It is assumed <paramref name="reader"/> is not null
        /// <br/>NOTE: It is assumed <paramref name="address"/> is valid</summary>
        /// <param name="reader">Reader</param>
        /// <param name="address">Stream position where the instance is defined</param>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        public delegate T ReadMethod_(ObjReader reader, long address);

        /// <summary>Constructor for <see cref="ObjReaderCache{T}"/>
        /// <br/>NOTE: It is assumed <paramref name="readMethod"/> is not null</summary>
        public ObjReaderCache(ReadMethod_ readMethod)
        {
            _ReadMethod = readMethod;
        }

        private readonly ReadMethod_ _ReadMethod;
        /// <summary>Method to read an instance from the stream</summary>
        public ReadMethod_ ReadMethod => _ReadMethod;

        private readonly Dictionary<int, T> _LoadedInstances = new Dictionary<int, T>();

        /// <summary>Attempts to get the instance at the specified stream position</summary>
        /// <param name="address">Stream position where the instance is defined</param>
        /// <param name="instance">Found instance</param>
        /// <returns>Whether or not successful</returns>
        public bool TryGet(int address, out T instance) =>
            _LoadedInstances.TryGetValue(address, out instance);

        /// <summary>Adds a loaded instance to the cache
        /// <br/>NOTE: It is assumed <paramref name="address"/> hasn't already been defined in the cache
        /// <br/>NOTE: It is assumed <paramref name="instance"/> is not null</summary>
        /// <param name="address">Stream position where the instance is defined</param>
        /// <param name="instance">Loaded instance</param>
        public void Add(int address, T instance) =>
            _LoadedInstances.Add(address, instance);
    }
}
