﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Objectoid
{
    /// <summary>Represents a value type</summary>
    public enum ValueType : byte
    {
        #region Null

        /// <summary>Value is null</summary>
        Null = 0xFF,

        #endregion

        #region Reference

        /// <summary>Value references an object</summary>
        Object = 0x00,

        /// <summary>Value references a property name</summary>
        PropertyName = 0x01,

        /// <summary>Value references an array</summary>
        Array = 0x02,

        /// <summary>Value references a string</summary>
        String = 0x03,

        #endregion

        #region Integer

        /// <summary>Value is an unsigned 8-bit integer</summary>
        UInt8 = 0x10,

        /// <summary>Value is a signed 8-bit integer</summary>
        Int8 = 0x11,

        /// <summary>Value is an unsigned 16-bit integer</summary>
        UInt16 = 0x12,

        /// <summary>Value is a signed 16-bit integer</summary>
        Int16 = 0x13,

        /// <summary>Value is an unsigned 32-bit integer</summary>
        UInt32 = 0x14,

        /// <summary>Value is a signed 32-bit integer</summary>
        Int32 = 0x15,

        /// <summary>Value is an unsigned 64-bit integer</summary>
        UInt64 = 0x16,

        /// <summary>Value is a signed 64-bit integer</summary>
        Int64 = 0x17,

        #endregion

        #region Float

        /// <summary>Value is a single-precision floating-point decimal</summary>
        Single = 0x20,

        /// <summary>Value is a double-precision floating-point decimal</summary>
        Double = 0x21,

        #endregion

        #region Misc

        /// <summary>Value is boolean</summary>
        Bool = 0x30,

        #endregion
    }


}
