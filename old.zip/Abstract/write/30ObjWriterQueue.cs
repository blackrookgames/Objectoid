﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Objectoid.Abstract
{
    /// <summary>Represents a queue of referenced instances to be written</summary>
    /// <typeparam name="T">Instance type</typeparam>
    internal class ObjWriterQueue<T>
    {
        /// <summary>Writes an instance to the stream
        /// <br/>NOTE: It is assumed neither <paramref name="writer"/> nor <paramref name="instance"/> are null</summary>
        /// <param name="writer">Writer</param>
        /// <param name="instance">Instance</param>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was disposed</exception>
        /// <exception cref="ObjectAlreadyWrittenException">It was attempted to modify a <see cref="ObjWriterRawObject"/> that was already written to the stream</exception>
        public delegate void WriteMethod_(ObjWriter writer, T instance);

        /// <summary>Represents a queue entry</summary>
        public class Entry_
        {
            /// <summary>Constructor for <see cref="Entry_"/>
            /// <br/>NOTE: It is assumed <paramref name="instance"/> is not null</summary>
            /// <param name="instance">Instance that needs to be saved</param>
            public Entry_(T instance)
            {
                _Instance = instance;
            }

            #region Entity

            private readonly T _Instance;

            /// <summary>Instance that needs to be saved</summary>
            public T Instance => _Instance;

            #endregion

            #region References

            private readonly List<long> _References = new List<long>();

            /// <summary>Stream positions where the instance is referenced</summary>
            public IEnumerable<long> References => _References;

            /// <summary>Number stream positions where the instance is referenced</summary>
            public int ReferenceCount => _References.Count;

            /// <summary>Adds a stream position where the instance is referenced
            /// <br/>NOTE: It is assumed <paramref name="position"/> is greater than or equal to zero</summary>
            /// <param name="position">Address </param>
            public void AddReference(long position)
            {
                _References.Add(position);
            }

            #endregion
        }

        /// <summary>Constructor for <see cref="ObjWriterQueue{T}"/>
        /// <br/>NOTE: It is assumed <paramref name="writeMethod"/> is not null</summary>
        public ObjWriterQueue(WriteMethod_ writeMethod)
        {
            _WriteMethod = writeMethod;
        }

        private readonly WriteMethod_ _WriteMethod;
        /// <summary>Method to write the instance to the stream</summary>
        public WriteMethod_ WriteMethod => _WriteMethod;

        private readonly Dictionary<T, Entry_> _EntriesByObject = new Dictionary<T, Entry_>();
        private readonly List<Entry_> _Entries = new List<Entry_>();

        /// <summary>Adds an instance to the queue
        /// <br/>If the instance is already in the queue, then only the reference is added
        /// <br/>NOTE: It is assumed <paramref name="reference"/> is greater than or equal to zero
        /// </summary>
        /// <param name="instance">Instance</param>
        /// <param name="reference">Stream position where the instance is referenced</param>
        /// <exception cref="ArgumentNullException"><paramref name="instance"/> is null</exception>
        public void AddInstance(T instance, long reference)
        {
            try
            {
                if (!_EntriesByObject.TryGetValue(instance, out Entry_ entry))
                {
                    entry = new Entry_(instance);
                    _EntriesByObject.Add(instance, entry);
                    _Entries.Add(entry);
                }
                entry.AddReference(reference);
            }
            catch when (instance == null)
            {
                throw new ArgumentNullException(nameof(instance));
            }
        }

        /// <summary>Attempts to retrieve the first instance from the queue, removing it from the queue</summary>
        /// <param name="entry">First entry</param>
        /// <returns>Whether or not successful</returns>
        public bool TryGetInstance(out Entry_ entry)
        {
            if (_Entries.Count > 0)
            {
                entry = _Entries[0];
                _EntriesByObject.Remove(entry.Instance);
                _Entries.RemoveAt(0);
                return true;
            }
            else
            {
                entry = null;
                return false;
            }
        }
    }
}
