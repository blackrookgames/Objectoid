﻿using System;
using System.IO;

namespace Objectoid.Abstract
{
    public partial class ObjWriterRawObject
    {
        /// <summary>Writes an object property</summary>
        /// <param name="name">Name</param>
        /// <param name="value">Value</param>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        public void WriteObject(PropertyName name, IObjObject value)
        {
            if (name == null) throw new ArgumentNullException(nameof(name));
            _Writer.QueuePropertyName_m(name);
            if (_Writer == null)
            {
                _Writer.WriteType_m(ValueType.Null);
                _Writer.WriteInt32_m(0);
            }
            else
            {
                _Writer.WriteType_m(ValueType.Object);
                _Writer.QueueObject_m(value);
            }
            __PropertyCount++;
        }

        /// <summary>Writes a property name property</summary>
        /// <param name="name">Name</param>
        /// <param name="value">Value</param>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        public void WritePropertyName(PropertyName name, PropertyName value)
        {
            if (name == null) throw new ArgumentNullException(nameof(name));
            _Writer.QueuePropertyName_m(name);
            if (_Writer == null)
            {
                _Writer.WriteType_m(ValueType.Null);
                _Writer.WriteInt32_m(0);
            }
            else
            {
                _Writer.WriteType_m(ValueType.PropertyName);
                _Writer.QueuePropertyName_m(value);
            }
            __PropertyCount++;
        }

        /// <summary>Writes a string property</summary>
        /// <param name="name">Name</param>
        /// <param name="value">Value</param>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        public void WriteString(PropertyName name, string value)
        {
            if (name == null) throw new ArgumentNullException(nameof(name));
            _Writer.QueuePropertyName_m(name);
            if (_Writer == null)
            {
                _Writer.WriteType_m(ValueType.Null);
                _Writer.WriteInt32_m(0);
            }
            else
            {
                _Writer.WriteType_m(ValueType.String);
                _Writer.QueueString_m(value);
            }
            __PropertyCount++;
        }

        /// <summary>Writes an unsigned 8-bit integer property</summary>
        /// <param name="name">Name</param>
        /// <param name="value">Value</param>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        public void WriteUInt8(PropertyName name, byte value)
        {
            if (name == null) throw new ArgumentNullException(nameof(name));
            _Writer.QueuePropertyName_m(name);
            _Writer.WriteType_m(ValueType.UInt8);
            _Writer.WriteUInt8_m(value);
            __PropertyCount++;
        }

        /// <summary>Writes a signed 8-bit integer property</summary>
        /// <param name="name">Name</param>
        /// <param name="value">Value</param>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        public void WriteInt8(PropertyName name, sbyte value)
        {
            if (name == null) throw new ArgumentNullException(nameof(name));
            _Writer.QueuePropertyName_m(name);
            _Writer.WriteType_m(ValueType.Int8);
            _Writer.WriteInt8_m(value);
            __PropertyCount++;
        }

        /// <summary>Writes an unsigned 16-bit integer property</summary>
        /// <param name="name">Name</param>
        /// <param name="value">Value</param>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        public void WriteUInt16(PropertyName name, ushort value)
        {
            if (name == null) throw new ArgumentNullException(nameof(name));
            _Writer.QueuePropertyName_m(name);
            _Writer.WriteType_m(ValueType.UInt16);
            _Writer.WriteUInt16_m(value);
            __PropertyCount++;
        }

        /// <summary>Writes a signed 16-bit integer property</summary>
        /// <param name="name">Name</param>
        /// <param name="value">Value</param>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        public void WriteInt16(PropertyName name, short value)
        {
            if (name == null) throw new ArgumentNullException(nameof(name));
            _Writer.QueuePropertyName_m(name);
            _Writer.WriteType_m(ValueType.Int16);
            _Writer.WriteInt16_m(value);
            __PropertyCount++;
        }

        /// <summary>Writes an unsigned 32-bit integer property</summary>
        /// <param name="name">Name</param>
        /// <param name="value">Value</param>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        public void WriteUInt32(PropertyName name, uint value)
        {
            if (name == null) throw new ArgumentNullException(nameof(name));
            _Writer.QueuePropertyName_m(name);
            _Writer.WriteType_m(ValueType.UInt32);
            _Writer.WriteUInt32_m(value);
            __PropertyCount++;
        }

        /// <summary>Writes a signed 32-bit integer property</summary>
        /// <param name="name">Name</param>
        /// <param name="value">Value</param>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        public void WriteInt32(PropertyName name, int value)
        {
            if (name == null) throw new ArgumentNullException(nameof(name));
            _Writer.QueuePropertyName_m(name);
            _Writer.WriteType_m(ValueType.Int32);
            _Writer.WriteInt32_m(value);
            __PropertyCount++;
        }

        /// <summary>Writes an unsigned 64-bit integer property</summary>
        /// <param name="name">Name</param>
        /// <param name="value">Value</param>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        public void WriteUInt64(PropertyName name, ulong value)
        {
            if (name == null) throw new ArgumentNullException(nameof(name));
            _Writer.QueuePropertyName_m(name);
            _Writer.WriteType_m(ValueType.UInt64);
            _Writer.WriteUInt64_m(value);
            __PropertyCount++;
        }

        /// <summary>Writes a signed 64-bit integer property</summary>
        /// <param name="name">Name</param>
        /// <param name="value">Value</param>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        public void WriteInt64(PropertyName name, long value)
        {
            if (name == null) throw new ArgumentNullException(nameof(name));
            _Writer.QueuePropertyName_m(name);
            _Writer.WriteType_m(ValueType.Int64);
            _Writer.WriteInt64_m(value);
            __PropertyCount++;
        }

        /// <summary>Writes a single-precision floating-point property</summary>
        /// <param name="name">Name</param>
        /// <param name="value">Value</param>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        public void WriteSingle(PropertyName name, float value)
        {
            if (name == null) throw new ArgumentNullException(nameof(name));
            _Writer.QueuePropertyName_m(name);
            _Writer.WriteType_m(ValueType.Single);
            _Writer.WriteSingle_m(value);
            __PropertyCount++;
        }

        /// <summary>Writes a double-precision floating-point property</summary>
        /// <param name="name">Name</param>
        /// <param name="value">Value</param>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        public void WriteDouble(PropertyName name, double value)
        {
            if (name == null) throw new ArgumentNullException(nameof(name));
            _Writer.QueuePropertyName_m(name);
            _Writer.WriteType_m(ValueType.Double);
            _Writer.WriteDouble_m(value);
            __PropertyCount++;
        }

        /// <summary>Writes a boolean property</summary>
        /// <param name="name">Name</param>
        /// <param name="value">Value</param>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        public void WriteBool(PropertyName name, bool value)
        {
            if (name == null) throw new ArgumentNullException(nameof(name));
            _Writer.QueuePropertyName_m(name);
            _Writer.WriteType_m(ValueType.Bool);
            _Writer.WriteBool_m(value);
            __PropertyCount++;
        }
    }
}

