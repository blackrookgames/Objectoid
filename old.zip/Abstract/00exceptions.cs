﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Objectoid.Abstract
{
    /// <summary>Thrown when attempting to add data to a raw object that has already been written to the stream</summary>
    public class ObjectAlreadyWrittenException : Exception
    {
        /// <summary>Constructor for <see cref="ObjectAlreadyWrittenException"/></summary>
        internal ObjectAlreadyWrittenException() :
            base("The raw object has already been written to the stream and cannot be modified.")
        { }
    }
}
