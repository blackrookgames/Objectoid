﻿using System;
using System.IO;
using Objectoid.Abstract;

namespace Objectoid
{
    /// <summary>Represents an Objectoid-structured document</summary>
    public class ObjDocument : ObjDocumentBase
    {
        #region ObjDocumentBase

        /// <inheritdoc/>
        protected override IObjObject MainObject_p => _MainObject;

        #endregion

        /// <summary>Creates an instance of <see cref="ObjDocument"/></summary>
        public ObjDocument()
        {
            _MainObject = new ObjObject(false);
        }

        private readonly ObjObject _MainObject;
        /// <summary>Main object</summary>
        public ObjObject MainObject => _MainObject;

        /// <summary>Loads data from the specified stream</summary>
        /// <param name="stream">Stream</param>
        /// <exception cref="ArgumentNullException"><paramref name="stream"/> is null</exception>
        /// <exception cref="ArgumentException"><paramref name="stream"/> does not support seeking
        /// <br/>or
        /// <br/><paramref name="stream"/> does not support reading</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">The stream has already been disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        public void Load(Stream stream) => Load_m(stream);

        /// <summary>Saves to the specified stream</summary>
        /// <param name="stream">Stream</param>
        /// <exception cref="ArgumentNullException"><paramref name="stream"/> is null</exception>
        /// <exception cref="ArgumentException"><paramref name="stream"/> does not support seeking
        /// <br/>or
        /// <br/><paramref name="stream"/> does not support writing</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">The stream has already been disposed</exception>
        /// <exception cref="OverflowException">It was attempted to reference an address higher than <see cref="int.MaxValue"/></exception>
        public void Save(Stream stream) => Save_m(stream, false, false);
    }
}
