﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;

namespace Objectoid.Abstract
{
    /// <summary>Represents a reader for an Objectoid document</summary>
    public partial class ObjReader : ObjRW
    {
        #region helper

        private static ObjectDisposedException StreamDisposed_m() =>
            new ObjectDisposedException("The stream associated with the reader has already been disposed.");

        /// <summary>Creates an <see cref="InvalidDataException"/> that references the specified stream position</summary>
        /// <param name="position">Stream position</param>
        /// <param name="message">Message</param>
        /// <returns>An <see cref="InvalidDataException"/> that references the specified stream position</returns>
        internal static InvalidDataException InvalidData_m(long position, string message) =>
            new InvalidDataException($"{message} 0x{position:X8}.");

        /// <summary>Reads and validates a reference address</summary>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Reference address is out of range</exception>
        internal int ReadAddress_m()
        {
            int address = ReadInt32_m();
            if (address < 0 || address >= Stream.Length)
                throw InvalidData_m(Stream.Position - 4, "Reference is out of range.");
            return address;
        }

        #endregion

        /// <summary>Constructor for <see cref="ObjReader"/></summary>
        /// <param name="stream">Stream</param>
        /// <exception cref="ArgumentNullException"><paramref name="stream"/> is null</exception>
        /// <exception cref="ArgumentException"><paramref name="stream"/> does not support seeking
        /// <br/>or
        /// <br/><paramref name="stream"/> does not support reading</exception>
        private ObjReader(Stream stream) :
            base(stream)
        {
            if (!stream.CanRead)
                throw new ArgumentException("The stream does not support reading.", nameof(stream));
        }

        /// <summary>Loads data to the specified object from the specified stream
        /// <br/>NOTE: It is assumed <paramref name="object"/> is not null</summary>
        /// <param name="stream">Stream</param>
        /// <param name="object">Object</param>
        /// <exception cref="ArgumentNullException"><paramref name="stream"/> is null</exception>
        /// <exception cref="ArgumentException"><paramref name="stream"/> does not support seeking
        /// <br/>or
        /// <br/><paramref name="stream"/> does not support reading</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">The stream has already been disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        internal static void Load_m(Stream stream, IObjObject @object)
        {
            ObjReader objReader = new ObjReader(stream);

            //Read header
            byte flagByte = objReader.ReadUInt8_m();
            objReader.SetIntIsLittleEndian_m((flagByte & 0b0001) != 0);
            objReader.SetFloatIsLittleEndian_m((flagByte & 0b0010) != 0);

            //Read and load first object
            int firstObjectAddress = objReader.ReadAddress_m();
            @object.Load(objReader.ReadObject_m(firstObjectAddress));
        }

        #region cache

        #region helper

        /// <summary>Reads the instance at the specified stream position
        /// <br/>NOTE: It is assumed <paramref name="cache"/> is not null
        /// <br/>NOTE: It is assumed <paramref name="address"/> is valid</summary>
        /// <typeparam name="T">Instance type</typeparam>
        /// <param name="cache">Cache</param>
        /// <param name="address">Stream position where the instance is defined</param>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        private T ReadInstance_m<T>(ObjReaderCache<T> cache, int address)
        {
            if (cache.TryGet(address, out T instance)) return instance;

            long returnPos = Stream.Position;
            Stream.Position = address;
            instance = cache.ReadMethod(this, address);
            Stream.Position = returnPos;

            return instance;
        }

        #endregion

        #region Object

        private readonly ObjReaderCache<ObjReaderRawObject> _ObjectCache = 
            new ObjReaderCache<ObjReaderRawObject>((ObjReader reader, long address) =>
            {
                ObjReaderRawObject rawObject = new ObjReaderRawObject(reader, address);

                //Property count
                int propertyCount = reader.ReadInt32_m();

                //Properties
                for (int i = 0; i < propertyCount; i++)
                {
                    //Name
                    int nameAddress = reader.ReadAddress_m();
                    PropertyName name = reader.ReadInstance_m(reader._PropertyNameCache, nameAddress);

                    //Type
                    long typeAddress = reader.Stream.Position;
                    ValueType type = reader.ReadType_m();
                    if (!_ReadValueMethods.TryGetValue(type, out ReadValueMethod_ readValueMethod))
                        throw InvalidData_m(typeAddress,
                            $"The type {((byte)type):X2} is unknown.");

                    //Value
                    ObjReaderValue value = readValueMethod(rawObject);

                    //Add property
                    rawObject.Add_m(new ObjReaderProperty(rawObject, address, name, value));
                }

                //Return
                return rawObject;
            });

        /// <summary>Reads a raw object
        /// <br/>NOTE: It is assumed <paramref name="address"/> is valid</summary>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        internal ObjReaderRawObject ReadObject_m(int address) => ReadInstance_m(_ObjectCache, address);

        #endregion

        #region PropertyName

        private readonly ObjReaderCache<PropertyName> _PropertyNameCache =
            new ObjReaderCache<PropertyName>((ObjReader reader, long address) =>
            {
                List<byte> chars = new List<byte>(32);
                while (true)
                {
                    byte b = reader.ReadUInt8_m();
                    if (b == 0) break;
                    chars.Add(b);
                }
                return new PropertyName(chars.ToArray());
            });

        /// <summary>Reads a property name
        /// <br/>NOTE: It is assumed <paramref name="address"/> is valid</summary>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        internal PropertyName ReadPropertyName_m(int address) => ReadInstance_m(_PropertyNameCache, address);

        #endregion

        #region String

        private readonly ObjReaderCache<string> _StringCache =
            new ObjReaderCache<string>((ObjReader reader, long address) =>
            {
                //Header
                int header = reader.ReadInt32_m();
                bool is8Bit = (header & int.MinValue) != 0;
                int length = header & (~int.MinValue);
                //Characters
                char[] chars = new char[length];
                if (is8Bit)
                {
                    for (int i = 0; i < length; i++)
                        chars[i] = (char)reader.ReadUInt8_m();
                }
                else
                {
                    for (int i = 0; i < length; i++)
                        chars[i] = (char)reader.ReadUInt16_m();
                }
                //Return
                return new string(chars);
            });

        /// <summary>Reads a string
        /// <br/>NOTE: It is assumed <paramref name="address"/> is valid</summary>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">Stream was already disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        internal string ReadString_m(int address) => ReadInstance_m(_StringCache, address);

        #endregion

        #endregion
    }

}
