﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;

namespace Objectoid.Abstract
{
    /// <summary>Represents a raw object read from a stream</summary>
    public class ObjReaderRawObject : IEnumerable<ObjReaderProperty>
    {
        #region IEnumerator

        IEnumerator IEnumerable.GetEnumerator() => _Properties.Values.GetEnumerator();

        /// <summary>Gets an enumerator for the raw object's properties</summary>
        /// <returns>An enumerator for the raw object's properties</returns>
        public IEnumerator<ObjReaderProperty> GetEnumerator() => _Properties.Values.GetEnumerator();

        #endregion

        /// <summary>Constructor for <see cref="ObjReaderRawObject"/>
        /// <br/>NOTE: It is assumed <paramref name="reader"/> is not null
        /// <br/>NOTE: It is assumed <paramref name="address"/> is valid</summary>
        /// <param name="reader">Reader associated with the raw object</param>
        /// <param name="address">Stream position where the object is defined</param>
        internal ObjReaderRawObject(ObjReader reader, long address)
        {
            _Reader = reader;
            _Address = address;
        }

        #region Reader

        private readonly ObjReader _Reader;

        /// <summary>Reader associated with the raw object</summary>
        public ObjReader Reader => _Reader;

        #endregion

        #region Address

        private readonly long _Address;

        /// <summary>Stream position where the object is defined</summary>
        public long Address => _Address;

        #endregion

        private readonly Dictionary<PropertyName, ObjReaderProperty> _Properties = 
            new Dictionary<PropertyName, ObjReaderProperty>();

        /// <summary>Number of properties</summary>
        public int Count => _Properties.Count;

        /// <summary>Gets the property with the specified name</summary>
        /// <param name="name">Name of the property</param>
        /// <returns>The property with the specified name</returns>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        /// <exception cref="InvalidDataException">Object does not contain an property of the specifeid name</exception>
        public ObjReaderProperty this[PropertyName name]
        {
            get
            {
                try
                {
                    if (!TryGet(name, out ObjReaderProperty property)) throw ObjReader.InvalidData_m(_Address,
                        $"Object does not contain a property named \"{name}\".");
                    return property;
                }
                catch when (name == null)
                {
                    throw new ArgumentNullException(nameof(name));
                }
            }
        }

        /// <summary>Attempts to get the property with the specified name</summary>
        /// <param name="name">Name of the property</param>
        /// <param name="property">Found property</param>
        /// <returns>Whether or not successful</returns>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null</exception>
        public bool TryGet(PropertyName name, out ObjReaderProperty property)
        {
            try
            {
                return _Properties.TryGetValue(name, out property);
            }
            catch when (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }
        }

        /// <summary>Adds the specified property to the stream
        /// <br/>NOTE: It is assumed <paramref name="property"/> is not null</summary>
        /// <param name="property">Property</param>
        /// <exception cref="InvalidDataException">The raw object already contains a property with the same name</exception>
        internal void Add_m(ObjReaderProperty property)
        {
            if (_Properties.ContainsKey(property.Name)) throw ObjReader.InvalidData_m(property.Address,
                $"The raw object already contains a property with the name \"{property.Name}\".");
            _Properties.Add(property.Name, property);
        }
    }
}
