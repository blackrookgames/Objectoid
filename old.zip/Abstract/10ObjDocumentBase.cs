﻿using System;
using System.IO;
using System.Security.Cryptography;

namespace Objectoid.Abstract
{
    /// <summary>Base class for Objectoid-structured documents</summary>
    public abstract class ObjDocumentBase
    {
        /// <summary>Loads data from the specified stream</summary>
        /// <param name="stream">Stream</param>
        /// <exception cref="InvalidOperationException"><see cref="MainObject_p"/> is null</exception>
        /// <exception cref="ArgumentNullException"><paramref name="stream"/> is null</exception>
        /// <exception cref="ArgumentException"><paramref name="stream"/> does not support seeking
        /// <br/>or
        /// <br/><paramref name="stream"/> does not support reading</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">The stream has already been disposed</exception>
        /// <exception cref="EndOfStreamException">End of the stream has been reached</exception>
        /// <exception cref="InvalidDataException">Data in stream is invalid</exception>
        protected void Load_m(Stream stream)
        {
            if (MainObject_p == null) throw new InvalidOperationException("The main object is null.");
            ObjReader.Load_m(stream, MainObject_p);
        }

        /// <summary>Saves to the specified stream</summary>
        /// <param name="stream">Stream</param>
        /// <param name="intIsLittleEndian">Whether or not integers are stored as little-endian</param>
        /// <param name="floatIsLittleEndian">Whether or not floats are stored as little-endian</param>
        /// <exception cref="InvalidOperationException"><see cref="MainObject_p"/> is null</exception>
        /// <exception cref="ArgumentNullException"><paramref name="stream"/> is null</exception>
        /// <exception cref="ArgumentException"><paramref name="stream"/> does not support seeking
        /// <br/>or
        /// <br/><paramref name="stream"/> does not support writing</exception>
        /// <exception cref="IOException">I/O error occured</exception>
        /// <exception cref="ObjectDisposedException">The stream has already been disposed</exception>
        /// <exception cref="OverflowException">It was attempted to reference an address higher than <see cref="int.MaxValue"/></exception>
        protected void Save_m(Stream stream, bool intIsLittleEndian, bool floatIsLittleEndian)
        {
            if (MainObject_p == null) throw new InvalidOperationException("The main object is null.");
            ObjWriter.Save_m(stream, MainObject_p, intIsLittleEndian, floatIsLittleEndian);
        }

        /// <summary>Main object</summary>
        protected abstract IObjObject MainObject_p { get; }
    }
}
